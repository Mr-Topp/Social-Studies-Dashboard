// List of every activity that turns work in, and which class it belongs to.
// The teacher dashboard uses this to put each turn-in under the right tab,
// grouped by unit and sorted by day (matching the Schoology day posts).
// To add a new activity: copy one line, change the id, title, course, unit, day, and path (its folder).
// course must be one of: "us-history", "world-history", "sociology", "government", "civics"
window.CLASS_COURSES = {
  "us-history":    "U.S. History",
  "world-history": "World History",
  "sociology":     "Sociology",
  "government":    "Government",
  "civics":        "Civics"
};

// Unit names for each class (same order and numbers as the Schoology unit pages).
window.CLASS_UNITS = {
  "us-history": {
    1: "Roaring 20s & the Great Depression",
    2: "World War II",
    3: "The Cold War",
    4: "Civil Rights",
    5: "Rise of Conservatism",
    6: "Modern America"
  },
  "world-history": {
    1: "Imperialism & the World Wars (1800–1945)",
    2: "Cold War & Decolonization",
    3: "The World Since 1991"
  },
  "sociology": {
    1: "Foundations, Perspectives & Methods",
    2: "Culture, Institutions & Society",
    3: "Socialization, the Self & Groups",
    4: "Stratification & Inequality"
  },
  "government": {
    1: "Foundations of the U.S. Constitution",
    2: "Political Beliefs, Linkage Institutions & Citizenship",
    3: "Judicial Branch",
    4: "Legislative Branch",
    5: "Executive Branch",
    6: "Checks & Balances and Iowa Government"
  },
  "civics": {
    1: "Founders' Files (Civics Test Q1–15)",
    2: "How the Government Works (Q16–62)",
    3: "Rights & Responsibilities (Q63–72)",
    4: "The 1776 Files (Q73–89)",
    5: "The 1800s (Q90–99)",
    6: "Modern America (Q100–118)",
    7: "Symbols, Holidays & Final Review (Q119–128)"
  }
};

// Part 1 units (the first half of the course). Kept separate so the current Unit 1–6 numbers stay the same.
window.CLASS_UNITS_PART1 = {
  "us-history": {
    1: "Founding & Citizenship",
    2: "Civil War & Reconstruction",
    3: "Westward & Industrial Expansion",
    4: "Progressive Era"
  },
  "world-history": {
    1: "Exploration & Global Trade",
    2: "Expanding Empires",
    3: "Renaissance, Reformation & New Ideas",
    4: "Revolutions & Industrialization"
  }
};

window.CLASS_ASSIGNMENTS = {
  // ---- World History · Unit 1 ----
  "divide-africa-day1":          { course: "world-history", unit: 1, day: 1, title: "Day 1 · Divide Africa", path: "divide-africa/", std: ["SS.9-12.WH.24"] },
  "day-2-hanoi-rat-hunt":        { course: "world-history", unit: 1, day: 2, title: "Day 2 · The Great Hanoi Rat Hunt (Reading)", path: "day-2-hanoi/", std: ["SS.9-12.WH.27", "SS.9-12.WH.24"] },
  "pacific-case-files":          { course: "world-history", unit: 1, day: 3, title: "Day 3 · Pacific Case Files", path: "pacific-case-files/", std: ["SS.9-12.WH.27", "SS.9-12.WH.25"] },
  "wwi-alliance-chain-reaction": { course: "world-history", unit: 1, day: 4, title: "Day 4 · WWI Alliance Chain Reaction", path: "wwi-alliance-chain-reaction/", std: ["SS.9-12.WH.29"] },
  "write-the-peace-treaty":      { course: "world-history", unit: 1, day: 5, title: "Day 5 · Cartoon Decoder", path: "write-the-peace-treaty/", std: ["SS.9-12.WH.31"] },
  "day6-world-in-crisis":        { course: "world-history", unit: 1, day: 6, title: "Day 6 · A World in Crisis", path: "day6-world-in-crisis/", std: ["SS.9-12.WH.31", "SS.9-12.WH.30"] },
  "day7-maus-reading-checks":    { course: "world-history", unit: 1, day: 7, title: "Day 7 · Maus I (Reading)", path: "day7-maus/", std: ["SS.9-12.WH.30", "SS.9-12.WH.33"] },
  "day7-warning-signs":          { course: "world-history", unit: 1, day: 7, title: "Day 7 · Spot the Warning Signs (now in Day 8)" },
  "day8-wwii-combined":          { course: "world-history", unit: 1, day: 8, title: "Day 8 · WWII Decisions & Warning Signs", path: "day8-wwii-decision-map/", std: ["SS.9-12.WH.29", "SS.9-12.WH.30"] },
  "day8-wwii-decision-map":      { course: "world-history", unit: 1, day: 8, title: "Day 8 · Decision Map (older version)" },
  "day9-maus2-reading-checks":   { course: "world-history", unit: 1, day: 9, title: "Day 9 · Maus II (Reading)", path: "day9-maus2/", std: ["SS.9-12.WH.30", "SS.9-12.WH.33"] },

  // ---- U.S. History · Unit 1 (Roaring 20s & Great Depression) · outside links, no dashboard turn-in (turnIn: false) ----
  "ush-u1-gd-assignment":     { course: "us-history", unit: 1, day: 1, turnIn: false, std: [], title: "Days 1–3 · Great Depression Assignment (Word)", path: "https://linnmarcsd-my.sharepoint.com/:w:/g/personal/fynnley_toppert_linnmar_k12_ia_us/IQAIG6nonFrZTpOf7Br6vdQGAVsfVh9lwF7Tub5K5XmvHl8?e=5uRa7c" },
  "ush-u1-cinderella-man":    { course: "us-history", unit: 1, day: 4, turnIn: false, std: [], title: "Days 4–5 · Cinderella Man (Movie)", path: "https://www.youtube.com/watch?v=ADPpVYZm-eM&t=1646s" },
  "ush-u1-cinderella-material": { course: "us-history", unit: 1, day: 4, turnIn: false, std: [], title: "Days 4–5 · Cinderella Man Material", path: "https://linnmarcsd-my.sharepoint.com/:b:/g/personal/fynnley_toppert_linnmar_k12_ia_us/IQAaaJk3W85dR4h3vaWo2FlTAV6B_M1nBDfCpMYw1j9tULw?e=5KfSha" },
  "ush-u1-summative-review":  { course: "us-history", unit: 1, day: 6, turnIn: false, std: [], title: "Day 6 · Summative Review (Blooket)", path: "https://dashboard.blooket.com/set/6add779bca99907cdd239286" },
  "ush-u1-summative":         { course: "us-history", unit: 1, day: 6, turnIn: false, std: [], title: "Day 6 · Summative", path: "https://drive.google.com/file/d/1T2wc7ijh28jghIDy52xqhfodpFvVWHsM/view?usp=sharing" },
  "ush-u1-summative-key":     { course: "us-history", unit: 1, day: 6, turnIn: false, std: [], title: "Day 6 · Summative Teacher Key", path: "https://drive.google.com/file/d/1graudmE3cWwLWBhDBhm1yrE_Gl8sh18D/view?usp=sharing" },

  // ---- U.S. History · Unit 2 (World War II) ----
  "wwii-graphic-reading-day1":   { course: "us-history", unit: 2, day: 1, title: "Day 1 · Maus I (Reading)", path: "wwii-graphic-reading/#day1", std: ["SS.9-12.US.29", "SS.9-12.US.30"] },
  "wwii-graphic-reading-day2":   { course: "us-history", unit: 2, day: 2, title: "Day 2 · Maus II (Reading)", path: "wwii-graphic-reading/#day2", std: ["SS.9-12.US.29", "SS.9-12.US.30"] },
  "wwii-graphic-reading-day3":   { course: "us-history", unit: 2, day: 3, title: "Day 3 · Anne Frank’s Diary (Reading)", path: "wwii-graphic-reading/#day3", std: ["SS.9-12.US.30"] },
  "wwii-graphic-reading-day4":   { course: "us-history", unit: 2, day: 4, title: "Day 4 · Fight on the Home Front (Reading)", path: "wwii-graphic-reading/#day4", std: ["SS.9-12.US.29", "SS.9-12.US.31", "SS.9-12.US.33"] },
  "wwii-graphic-reading-day5":   { course: "us-history", unit: 2, day: 5, title: "Day 5 · Japanese American Incarceration Comics (Reading)", path: "wwii-graphic-reading/#day5", std: ["SS.9-12.US.31", "SS.9-12.US.33"] },

  // ---- Sociology · Unit 1 ----
  "sociology-day-1-reading":                  { course: "sociology", unit: 1, day: 1, title: "Day 1 · What Is Sociology? (Reading)", path: "sociology/day-1-reading/", std: ["SS.9-12.Soc.2"] },
  "sociology-day-2-sociological-imagination": { course: "sociology", unit: 1, day: 2, title: "Day 2 · The Sociological Imagination (Reading)", path: "sociology/day-2-sociological-imagination/", std: ["SS.9-12.Soc.2"] },
  "sociology-day-3-founders":                 { course: "sociology", unit: 1, day: 3, title: "Day 3 · Origins and Founders (Reading)", path: "sociology/day-3-founders/", std: ["SS.9-12.Soc.4"] },
  "sociology-day-4-perspectives":             { course: "sociology", unit: 1, day: 4, title: "Day 4 · Sociological Perspectives (Reading)", path: "sociology/day-4-perspectives/", std: ["SS.9-12.Soc.4"] },
  "sociology-theory-casebook":                { course: "sociology", unit: 1, day: 4, title: "Day 4 · Theory Casebook", path: "day-4-theory-casebook/", std: ["SS.9-12.Soc.4"] },
  "sociology-day-7-research-ethics":          { course: "sociology", unit: 1, day: 7, title: "Day 7 · Ethics in Sociological Research (Reading)", path: "sociology/day-7-research-ethics/", std: ["SS.9-12.Soc.1"] },
  "sociology-unit1-review-seahaven":          { course: "sociology", unit: 1, title: "Unit 1 Review · Escape from Seahaven", path: "sociology-ethics-review/", std: ["SS.9-12.Soc.2", "SS.9-12.Soc.4", "SS.9-12.Soc.1"] },

  // ---- Sociology · Unit 2 ----
  "sociology-unit2-day1-first-shift":         { course: "sociology", unit: 2, day: 1, title: "Day 1 · First Shift: Status, Roles & Norms", path: "sociology/unit2-day1-first-shift/", std: ["SS.9-12.Soc.5", "SS.9-12.Soc.6", "SS.9-12.Soc.7"] },
  "sociology-unit2-arrival-culture":          { course: "sociology", unit: 2, day: 2, title: "Day 2 · The Arrival: A New Culture", path: "sociology/arrival-culture/", std: ["SS.9-12.Soc.5", "SS.9-12.Soc.6"] },
  "sociology-unit2-day3-culture-shock":      { course: "sociology", unit: 2, day: 3, title: "Day 3 · Culture Shock Exchange", path: "sociology/unit2-day3-culture-shock-exchange/", std: ["SS.9-12.Soc.6", "SS.9-12.Soc.5"] },

  // ---- Government · Unit 1 ----
  "gov-stranded-day1":                { course: "government", unit: 1, day: 1, title: "Day 1 · Stranded: Govern or Collapse", path: "civics/stranded-government/", std: ["SS.9-12.Gov.1", "SS.9-12.Gov.5"] },
  "gov-my-country-day3":              { course: "government", unit: 1, day: 3, title: "Day 3 · My Country, My Rules", path: "civics/my-country-my-rules/", std: ["SS.9-12.Gov.1", "SS.9-12.Gov.4"] },
  "gov-articles-day5":                { course: "government", unit: 1, day: 5, title: "Day 5 · 13 States. One Mess.", path: "civics/articles-confederation-game/", std: ["SS.9-12.Gov.9"] },
  "gov-missing-constitution-day7":    { course: "government", unit: 1, day: 7, title: "Day 7 · The Missing Constitution", path: "civics/missing-constitution/", std: ["SS.9-12.Gov.4"] },
  "gov-democracy-visualized-day1":    { course: "government", unit: 1, day: 1, title: "Day 1 · Purposes of Government (Reading)", path: "civics/democracy-visualized/#day1", std: ["SS.9-12.Gov.1"] },
  "gov-democracy-visualized-day2":    { course: "government", unit: 1, day: 2, title: "Day 2 · Social Contract & Rule of Law (Reading)", path: "civics/democracy-visualized/#day2", std: ["SS.9-12.Gov.14"] },
  "gov-democracy-visualized-day7":    { course: "government", unit: 1, day: 7, title: "Day 7 · The Constitution (Reading)", path: "civics/democracy-visualized/#day7", std: ["SS.9-12.Gov.4"] },
  "gov-democracy-visualized-day9":    { course: "government", unit: 1, day: 9, title: "Day 9 · Federalism & Iowa Government (Reading)", path: "civics/democracy-visualized/#day9", std: ["SS.9-12.Gov.9"] },
  // ---- Government · Unit 1 · printed/outside resources from the Schoology day posts (links only, no turn-in) ----
  "gov-u1-d2-why-government": { course: "government", unit: 1, day: 2, turnIn: false, std: [], title: "Day 2 · Why Government? — iCivics (Printed)", path: "https://linkschool.org/wp-content/uploads/2024/06/Rising-7th-Grade-History.pdf" },
  "gov-u1-d2-why-government-key": { course: "government", unit: 1, day: 2, turnIn: false, std: [], title: "Day 2 · Why Government? Answer Key", path: "https://ed.icivics.org/resource-assets/lesson_plan/10454/assets/why_government_answer_key.pdf" },
  "gov-u1-d2-blooket": { course: "government", unit: 1, day: 2, turnIn: false, std: [], title: "Day 2 · Blooket", path: "https://dashboard.blooket.com/set/68cade675c6118507c3aacd4" },
  "gov-u1-d3-my-country-example": { course: "government", unit: 1, day: 3, turnIn: false, std: [], title: "Day 3 · My Country, My Rules Example", path: "https://linnmarcsd-my.sharepoint.com/:b:/g/personal/fynnley_toppert_linnmar_k12_ia_us/IQCdMhmH97u4SL9wlKVMH2n5AaYxphYqCYYHfmlLN1e0YKc?e=R3Rinw" },
  "gov-u1-d4-scavenger-hunt": { course: "government", unit: 1, day: 4, turnIn: false, std: [], title: "Day 4 · Founding-Idea Scavenger Hunt (Printed)", path: "https://linnmarcsd-my.sharepoint.com/:w:/g/personal/fynnley_toppert_linnmar_k12_ia_us/IQADcWjqUzgBQoSnVOb7LNykAVObTUGWWPE1nDh5aqajXe8?e=IA4y6k" },
  "gov-u1-d5-aofc-together": { course: "government", unit: 1, day: 5, turnIn: false, std: [], title: "Day 5 · Articles of Confederation — Do Together", path: "https://linnmarcsd-my.sharepoint.com/:b:/g/personal/fynnley_toppert_linnmar_k12_ia_us/IQCUY660iFbdRqkeKEGH08rrATBTFIPSfFWgWYozVo_zlrI?e=Ygx6GN" },
  "gov-u1-d5-aoc": { course: "government", unit: 1, day: 5, turnIn: false, std: [], title: "Day 5 · Articles of Confederation (Printed)", path: "https://linnmarcsd-my.sharepoint.com/:b:/g/personal/fynnley_toppert_linnmar_k12_ia_us/IQDWzKQ8oz4RTKNS8_jCz9waAY1mQa7tEb58TEevIc7SvPU?e=8ERHfh" },
  "gov-u1-d6-compromises": { course: "government", unit: 1, day: 6, turnIn: false, std: [], title: "Day 6 · Constitutional Compromises — iCivics (Printed)", path: "https://ed.icivics.org/resource-assets/lesson_plan/2624198/assets/major_clash_student_docs.pdf" },
  "gov-u1-d6-compromises-key": { course: "government", unit: 1, day: 6, turnIn: false, std: [], title: "Day 6 · Constitutional Compromises Answer Key", path: "https://ed.icivics.org/resource-assets/lesson_plan/2624198/assets/major_clash_answer_key.pdf" },
  "gov-u1-d6-fed-antifed": { course: "government", unit: 1, day: 6, turnIn: false, std: [], title: "Day 6 · Federalists vs. Anti-Federalists — iCivics (Printed)", path: "https://ed.icivics.org/resource-assets/lesson_plan/403058/assets/federalists_and_anti-federalists_student_docs.pdf" },
  "gov-u1-d6-fed-antifed-key": { course: "government", unit: 1, day: 6, turnIn: false, std: [], title: "Day 6 · Federalists vs. Anti-Federalists Answer Key", path: "https://ed.icivics.org/resource-assets/lesson_plan/403058/assets/federalists_and_anti-federalists_answer_key.pdf" },
  "gov-u1-d7-notes": { course: "government", unit: 1, day: 7, turnIn: false, std: [], title: "Day 7 · Constitution Notes (Printed)", path: "https://linnmarcsd-my.sharepoint.com/:w:/g/personal/fynnley_toppert_linnmar_k12_ia_us/IQAwfWzZ2W9DTKAoWz9NNRRZAQfnJhpOBpCul4BVRPJmELU?e=dveBI4" },
  "gov-u1-d8-notes": { course: "government", unit: 1, day: 8, turnIn: false, std: [], title: "Day 8 · Bill of Rights Notes (Printed)", path: "https://linnmarcsd-my.sharepoint.com/:w:/g/personal/fynnley_toppert_linnmar_k12_ia_us/IQCqn_k7nmtPSaVOcFMTyTGVAaV1F9ctGn30rNW751H_Sn8?e=LWjXHe" },
  "gov-u1-d8-matching": { course: "government", unit: 1, day: 8, turnIn: false, std: [], title: "Day 8 · Matching the Bill of Rights (Printed)", path: "https://linnmarcsd-my.sharepoint.com/:p:/g/personal/fynnley_toppert_linnmar_k12_ia_us/IQDkLW0Q7EiKRo61374-4jmZAboewXYpSzSZjYvdtkPRmYo?e=S6EmYZ" },
  "gov-u1-d8-do-i-have-a-right": { course: "government", unit: 1, day: 8, turnIn: false, std: [], title: "Day 8 · Do I Have a Right? — iCivics Game", path: "https://ed.icivics.org/resources/game/42/do-i-have-a-right" },
  "gov-u1-d9-fed-state-local": { course: "government", unit: 1, day: 9, turnIn: false, std: [], title: "Day 9 · Federal, State, Local or Shared? — Do Together", path: "https://linnmarcsd-my.sharepoint.com/:w:/g/personal/fynnley_toppert_linnmar_k12_ia_us/IQAeTpymm_epSYB6uzJUoRCDAejc7s4Awhkr0Kqt5LPrTCA?e=B8W7yf" },
  "gov-u1-d9-federal-in-federalism": { course: "government", unit: 1, day: 9, turnIn: false, std: [], title: "Day 9 · The Federal in Federalism — iCivics (Printed)", path: "https://ed.icivics.org/resource-assets/lesson_plan/562135/assets/the_federal_in_federalism_student_docs.pdf" },
  "gov-u1-d9-federal-in-federalism-key": { course: "government", unit: 1, day: 9, turnIn: false, std: [], title: "Day 9 · The Federal in Federalism Answer Key", path: "https://ed.icivics.org/resource-assets/lesson_plan/562135/assets/the_federal_in_federalism_answer_key.pdf" },
  "gov-u1-d10-review": { course: "government", unit: 1, day: 10, turnIn: false, std: [], title: "Day 10 · Summative Review (Blooket)", path: "https://dashboard.blooket.com/set/6a998e452d347390093ca079" },
  "gov-u1-d10-summative": { course: "government", unit: 1, day: 10, turnIn: false, std: [], title: "Day 10 · Summative", path: "https://linnmarcsd-my.sharepoint.com/:b:/g/personal/fynnley_toppert_linnmar_k12_ia_us/IQCGLRsv7tXsQaDgBtq4yXFXAQuZIvlcnW9JtWfAPvag2J0?e=g8xWZh" },
  "gov-u1-d10-summative-key": { course: "government", unit: 1, day: 10, turnIn: false, std: [], title: "Day 10 · Summative Answer Key", path: "https://linnmarcsd-my.sharepoint.com/:b:/g/personal/fynnley_toppert_linnmar_k12_ia_us/IQDTO0_A_K1YT5edC-U6trraAf9vzCIwAMgZy0LwzzLgsvg?e=rRINiN" },

  // ---- Government · Unit 2 ----
  "gov-unit2-day1-the-feed":          { course: "government", unit: 2, day: 1, title: "Day 1 · Decision Desk: Ideology vs. Party", path: "civics/unit2-day1-the-feed/", std: ["SS.9-12.Gov.12"] },
  "gov-unit2-day2-fair-game":         { course: "government", unit: 2, day: 2, title: "Day 2 · Fair Game: Comparing the Parties", path: "civics/unit2-day2-fair-game/", std: ["SS.9-12.Gov.12"] },
  "gov-unit2-day2-lobby-day":         { course: "government", unit: 2, day: 4, title: "Day 4 · Lobby Day: Interest Groups & Media", path: "civics/unit2-day2-lobby-day/", std: ["SS.9-12.Gov.12"] },
  // ---- Government · Unit 2 · activities from the Schoology day posts (links only, no turn-in) ----
  "gov-u2-d1-poster": { course: "government", unit: 2, day: 1, turnIn: false, std: [], title: "Days 1–3 · Political Party Poster (Printed)", path: "https://docs.google.com/document/d/1Z8OsrG8eBL8005dEy6XuV9o7wvWctfCvm4g2-h-AmFQ/edit?usp=sharing" },
  "gov-u2-d1-poster-directions": { course: "government", unit: 2, day: 1, turnIn: false, std: [], title: "Days 1–3 · Political Party Poster Directions", path: "https://linnmarcsd-my.sharepoint.com/:p:/g/personal/fynnley_toppert_linnmar_k12_ia_us/IQDKPVnodH6XRaNjq_Hy3NjXATRK4fMXb5Pi0YSG_d-qA_k?e=C064xb" },
  "gov-u2-d2-pew-quiz": { course: "government", unit: 2, day: 2, turnIn: false, std: [], title: "Day 2 · Pew Political Typology Quiz (Optional)", path: "https://www.pewresearch.org/politics/quiz/political-typology/" },
  "gov-u2-d3-signal-break": { course: "government", unit: 2, day: 3, turnIn: false, std: [], title: "Day 3 · Signal Break (Game)", path: "https://signal-break-classroom.neotboy.chatgpt.site/" },
  "gov-u2-d4-interest-groups": { course: "government", unit: 2, day: 4, turnIn: false, std: [], title: "Day 4 · Interest Groups — iCivics (Printed)", path: "https://ed.icivics.org/resource-assets/lesson_plan/166930/assets/interest_groups_student_docs.pdf" },
  "gov-u2-d4-interest-groups-key": { course: "government", unit: 2, day: 4, turnIn: false, std: [], title: "Day 4 · Interest Groups Answer Key", path: "https://ed.icivics.org/resource-assets/lesson_plan/166930/assets/interest_groups_answer_key.pdf" },
  "gov-u2-d5-election-sim": { course: "government", unit: 2, day: 5, turnIn: false, std: [], title: "Day 5 · Presidential Election Simulation (2 Player)", path: "https://misterharms.com/games/electoral-college-map-game" },
  "gov-u2-d5-win-white-house": { course: "government", unit: 2, day: 5, turnIn: false, std: [], title: "Day 5 · Win the White House — iCivics Game", path: "https://ed.icivics.org/resources/game/67038/win-the-white-house" },
  "gov-u2-d6-civics-exam": { course: "government", unit: 2, day: 6, turnIn: false, std: [], title: "Day 6 · Civics Exam (Google Form)", path: "https://docs.google.com/forms/d/e/1FAIpQLSfDhGXMg7OP24DFhTdPQnHNsOoGgSS-pnDWpKadJ1U2smjpoA/viewform?usp=publish-editor" },
  "gov-u2-d7-review": { course: "government", unit: 2, day: 7, turnIn: false, std: [], title: "Day 7 · Summative Review (Blooket)", path: "https://dashboard.blooket.com/set/6aa09dfe760efeaa1135c5b7" },
  "gov-u2-d7-summative": { course: "government", unit: 2, day: 7, turnIn: false, std: [], title: "Day 7 · Summative", path: "https://linnmarcsd-my.sharepoint.com/:w:/g/personal/fynnley_toppert_linnmar_k12_ia_us/IQAsHiWOSrOESo-agkGYeF-6AcU5jvfuw1oM0UYp-KPoIKo?e=9mAl4u" },
  "gov-u2-d7-summative-key": { course: "government", unit: 2, day: 7, turnIn: false, std: [], title: "Day 7 · Summative Answer Key", path: "https://linnmarcsd-my.sharepoint.com/:w:/g/personal/fynnley_toppert_linnmar_k12_ia_us/IQDHa8vAMIBIQq5Z_igFdj6EAYotMPKNH6Y9D9sYH6g1-IY?e=Xz0RaZ" },

  // ---- Government · Unit 3 (Judicial) · activities from the Schoology day posts (links only, no turn-in) ----
  "gov-u3-argument-wars": { course: "government", unit: 3, day: 1, turnIn: false, std: [], title: "Days 1–2 · Argument Wars — iCivics Game", path: "https://ed.icivics.org/games/argument-wars" },
  "gov-u3-court-quest": { course: "government", unit: 3, day: 1, turnIn: false, std: [], title: "Days 1–2 · Court Quest — iCivics Game", path: "https://ed.icivics.org/node/853/resource#game-page-flash-game-container" },
  "gov-u3-d1-interpreting": { course: "government", unit: 3, day: 1, turnIn: false, std: [], title: "Day 1 · Interpreting the Constitution — iCivics (Printed)", path: "https://ed.icivics.org/resource-assets/lesson_plan/587/assets/interpreting_the_constitution_student_docs.pdf" },
  "gov-u3-d1-interpreting-key": { course: "government", unit: 3, day: 1, turnIn: false, std: [], title: "Day 1 · Interpreting the Constitution Answer Key", path: "https://ed.icivics.org/resource-assets/lesson_plan/587/assets/interpreting_the_constitution_answer_key.pdf" },
  "gov-u3-d1-supreme": { course: "government", unit: 3, day: 1, turnIn: false, std: [], title: "Day 1 · Supreme in Supreme Court — iCivics (Printed)", path: "https://ed.icivics.org/resource-assets/lesson_plan/616/assets/supreme_in_supreme_court_student_docs.pdf" },
  "gov-u3-d1-supreme-key": { course: "government", unit: 3, day: 1, turnIn: false, std: [], title: "Day 1 · Supreme in Supreme Court Answer Key", path: "https://ed.icivics.org/resource-assets/lesson_plan/616/assets/supreme_in_supreme_court_answer_key.pdf" },
  "gov-u3-d2-case-project-example": { course: "government", unit: 3, day: 2, turnIn: false, std: [], title: "Day 2 · Supreme Court Case Project Example", path: "https://linnmarcsd-my.sharepoint.com/:p/g/personal/fynnley_toppert_linnmar_k12_ia_us/IQD0fz0PCgvAQpJPlX--T7xSAXLSoDIix8Gs28wZ_90Rbb0?e=5oLw6R" },
  "gov-u3-d3-review": { course: "government", unit: 3, day: 3, turnIn: false, std: [], title: "Day 3 · Summative Review (Blooket)", path: "https://dashboard.blooket.com/set/6abe6bb22cd0b625b10babad" },
  "gov-u3-d3-summative": { course: "government", unit: 3, day: 3, turnIn: false, std: [], title: "Day 3 · Judicial Summative", path: "https://linnmarcsd-my.sharepoint.com/:w/g/personal/fynnley_toppert_linnmar_k12_ia_us/IQA6E-D0L4FZSqQHsenxDH2oAeCuLKZWepPZbSuON2jwoDc?e=64u4TI" },
  // ---- Government · Unit 4 (Legislative) ----
  "gov-u4-d1-branches-of-power": { course: "government", unit: 4, day: 1, turnIn: false, std: [], title: "Day 1 · Branches of Power — iCivics Game", path: "https://ed.icivics.org/resources/game/74/branches-of-power" },
  "gov-u4-d1-first-branch": { course: "government", unit: 4, day: 1, turnIn: false, std: [], title: "Day 1 · First Branch — iCivics (Printed)", path: "https://ed.icivics.org/resources/lesson_plan/3018136/first-branch-legislative" },
  "gov-u4-congress-drop": { course: "government", unit: 4, day: 1, turnIn: false, std: [], title: "Days 1–2 · Congress Drop (Game)", path: "https://congress-drop-live.floot.app/" },
  "gov-u4-lawcraft": { course: "government", unit: 4, day: 2, turnIn: false, std: [], title: "Days 2–3 · LawCraft — iCivics Game", path: "https://ed.icivics.org/resources/game/593/lawcraft" },
  "gov-u4-d2-poster": { course: "government", unit: 4, day: 2, turnIn: false, std: [], title: "Day 2 · Bill to Law Poster (Printed)", path: "https://linnmarcsd-my.sharepoint.com/:b/g/personal/fynnley_toppert_linnmar_k12_ia_us/IQDZKivJQTMCToTLxsbAvRx-AeG08DTtcj8cNcXV4pUvvK0?e=4TfkoA" },
  "gov-u4-d3-scenario-game": { course: "government", unit: 4, day: 3, turnIn: false, std: [], title: "Day 3 · Congress Scenario Game", path: "https://capitol-crisis-live.floot.app/" },
  "gov-u4-d4-review": { course: "government", unit: 4, day: 4, turnIn: false, std: [], title: "Day 4 · Summative Review (Blooket)", path: "https://dashboard.blooket.com/set/6ac2eab3b78211c196153a34" },
  "gov-u4-d4-summative": { course: "government", unit: 4, day: 4, turnIn: false, std: [], title: "Day 4 · Legislative Summative", path: "https://docs.google.com/document/d/1xCF77ZzM9EnyxgAWGcdPArbRrlAvzOpACsMcbn4hEOc/edit?usp=sharing" },
  // ---- Government · Unit 5 (Executive) ----
  "gov-u5-d1-for-the-president": { course: "government", unit: 5, day: 1, turnIn: false, std: [], title: "Day 1 · For the President: All in a Day's Work — iCivics (Printed)", path: "https://ed.icivics.org/resource-assets/lesson_plan/613/assets/for_the_president_all_in_a_days_work_student_docs.pdf" },
  "gov-u5-d1-for-the-president-key": { course: "government", unit: 5, day: 1, turnIn: false, std: [], title: "Day 1 · For the President Answer Key", path: "https://ed.icivics.org/resource-assets/lesson_plan/613/assets/for_the_president_all_in_a_days_work_answer_key.pdf" },
  "gov-u5-d2-second-branch": { course: "government", unit: 5, day: 2, turnIn: false, std: [], title: "Day 2 · Second Branch: The Executive — iCivics (Printed)", path: "https://ed.icivics.org/resource-assets/lesson_plan/3184562/assets/second_branch_the_executive_hs_student_docs.pdf" },
  "gov-u5-d2-second-branch-key": { course: "government", unit: 5, day: 2, turnIn: false, std: [], title: "Day 2 · Second Branch Answer Key", path: "https://ed.icivics.org/resource-assets/lesson_plan/3184562/assets/second_branch_the_executive_hs_answer_key.pdf" },
  "gov-u5-d3-very-big-branch": { course: "government", unit: 5, day: 3, turnIn: false, std: [], title: "Day 3 · A Very Big Branch — iCivics (Printed)", path: "https://ed.icivics.org/resource-assets/lesson_plan/317985/assets/a_very_big_branch_student_docs.pdf" },
  "gov-u5-d3-very-big-branch-key": { course: "government", unit: 5, day: 3, turnIn: false, std: [], title: "Day 3 · A Very Big Branch Answer Key", path: "https://ed.icivics.org/resource-assets/lesson_plan/317985/assets/a_very_big_branch_answer_key.pdf" },
  "gov-u5-d3-executive-command": { course: "government", unit: 5, day: 3, turnIn: false, std: [], title: "Day 3 · Executive Command — iCivics Game", path: "https://ed.icivics.org/games/executive-command" },
  "gov-u5-d4-review": { course: "government", unit: 5, day: 4, turnIn: false, std: [], title: "Day 4 · Summative Review (Blooket)", path: "https://dashboard.blooket.com/set/6ac83efba124fe7811777ef9" },
  "gov-u5-d4-summative": { course: "government", unit: 5, day: 4, turnIn: false, std: [], title: "Day 4 · Executive Summative", path: "https://linnmarcsd-my.sharepoint.com/:w/g/personal/fynnley_toppert_linnmar_k12_ia_us/IQCzCufjdG-FT7lgR_cdXoIEAcIqSvc7-LB8rbHBlK7eOIM?e=aTJ8tU" },

  // ---- Civics (Iowa civics test prep) · Friday 1 ----
  "civics-test-s1-presentation":     { course: "civics", hideLink: true, unit: 1, title: "Founders' Files (Slides)", path: "civics/civics-test-s1-presentation/", std: ["SS.9-12.Gov.3", "SS.9-12.Gov.4"] },
  "civics-test-s1-founders-defense":  { course: "civics", unit: 1, title: "Founders' Defense", path: "civics/civics-test-s1-founders-defense/", std: ["SS.9-12.Gov.3", "SS.9-12.Gov.4"] },

  // ---- Civics (Iowa civics test prep) · Fridays 2–7 (exit tickets on each Friday's presentation) ----
  "civics-f2-presentation": { course: "civics", hideLink: true, unit: 2, title: "How the Government Works (Slides)", path: "civics/friday2-government-presentation/", std: ["SS.9-12.Gov.6", "SS.9-12.Gov.7", "SS.9-12.Gov.8"] },
  "civics-f2-government-arcade": { course: "civics", unit: 2, title: "Government Arcade", path: "civics/day2-government-arcade/", std: ["SS.9-12.Gov.6", "SS.9-12.Gov.7", "SS.9-12.Gov.8", "SS.9-12.Gov.9", "SS.9-12.Gov.18"] },
  "civics-f3-presentation": { course: "civics", hideLink: true, unit: 3, title: "Rights & Responsibilities (Slides)", path: "civics/friday3-rights-presentation/", std: ["SS.9-12.Gov.14", "SS.9-12.Gov.17"] },
  "civics-f3-pixel-town": { course: "civics", unit: 3, title: "Pixel Town: Civic Quest", path: "civics/pixel-town-day3-game/", std: ["SS.9-12.Gov.13", "SS.9-12.Gov.14", "SS.9-12.Gov.17"] },
  "civics-f4-presentation": { course: "civics", hideLink: true, unit: 4, title: "The 1776 Files (Slides)", path: "civics/friday4-1776-presentation/", std: ["SS.9-12.Gov.3", "SS.9-12.Gov.15"] },
  "civics-f4-1776-files": { course: "civics", unit: 4, title: "The 1776 Files", path: "civics/friday4-1776-files-game/", std: ["SS.9-12.Gov.3", "SS.9-12.Gov.15"] },
  "civics-f5-presentation": { course: "civics", hideLink: true, unit: 5, title: "The 1800s (Slides)", path: "civics/friday5-1800s-civics-presentation/", std: ["SS.9-12.Gov.14", "SS.9-12.Gov.15", "SS.9-12.Gov.3"] },
  "civics-f5-1800s-express": { course: "civics", unit: 5, title: "The 1800s Express", path: "civics/friday5-1800s-express-game/", std: ["SS.9-12.Gov.14", "SS.9-12.Gov.15", "SS.9-12.Gov.3"] },
  "civics-f6-presentation": { course: "civics", hideLink: true, unit: 6, title: "Modern America (Slides)", path: "civics/friday6-modern-america-presentation/", std: ["SS.9-12.Gov.11", "SS.9-12.Gov.14", "SS.9-12.Gov.15"] },
  "civics-f7-presentation": { course: "civics", hideLink: true, unit: 7, title: "Symbols, Holidays & Final Review (Slides)", path: "civics/friday7-symbols-final-review-presentation/", std: ["SS.9-12.Gov.16"] },
  // Added 2026-11-01: past Drive assignments rebuilt as online activities for empty lesson days
  "ush-p1u1-d1-founding": { course: "us-history", unit: 1, day: 1, part: 1, title: "Day 1 · The Rider: Who Was in the Promise?", path: "us-history/p1u1-d1-founding/", std: ["SS.9-12.US.2", "SS.9-12.US.1"] },
  "ush-p1u1-d2-articles": { course: "us-history", unit: 1, day: 2, part: 1, title: "Day 2 · Clerk of a Broke Congress", path: "us-history/p1u1-d2-articles/", std: ["SS.9-12.US.2"] },
  "ush-p1u1-d3-convention": { course: "us-history", unit: 1, day: 3, part: 1, title: "Day 3 · Behind Closed Doors", path: "us-history/p1u1-d3-convention/", std: ["SS.9-12.US.3", "SS.9-12.US.2"] },
  "ush-p1u1-d4-constitution": { course: "us-history", unit: 1, day: 4, part: 1, title: "Day 4 · Power Watch, 1787–1868", path: "us-history/p1u1-d4-constitution/", std: ["SS.9-12.US.2"] },
  "ush-p1u1-d5-citizenship": { course: "us-history", unit: 1, day: 5, part: 1, title: "Day 5 · Who Counted? 1776–1870", path: "us-history/p1u1-d5-citizenship/", std: ["SS.9-12.US.1"] },
  "ush-p1u4-d2-labor": { course: "us-history", unit: 4, day: 2, part: 1, title: "Day 2 · Union Leader: Haymarket to Pullman", path: "us-history/p1u4-d2-labor/", std: ["SS.9-12.US.14"] },
  "ush-p1u4-d5-big-business": { course: "us-history", unit: 4, day: 5, part: 1, title: "Day 5 · TR's Adviser: Trust-Busting", path: "us-history/p1u4-d5-big-business/", std: ["SS.9-12.US.16", "SS.9-12.US.14"] },
  "ush-p1u4-d6-suffrage": { course: "us-history", unit: 4, day: 6, part: 1, title: "Day 6 · Road to the 19th Amendment", path: "us-history/p1u4-d6-suffrage/", std: ["SS.9-12.US.15", "SS.9-12.US.18"] },
  "ush-u1-d3-responses-iowans": { course: "us-history", unit: 1, day: 3, title: "Day 3 · Iowa Farm Family, 1929–1938", path: "us-history/u1-d3-responses-iowans/", std: ["SS.9-12.US.25", "SS.9-12.US.27", "SS.9-12.US.28"] },
  "ush-u2-d8-common-good": { course: "us-history", unit: 2, day: 8, title: "Day 8 · 1943 Ration Book", path: "us-history/u2-d8-common-good/", std: ["SS.9-12.US.34"] },
  "ush-u3-d1-allies-enemies": { course: "us-history", unit: 3, day: 1, title: "Day 1 · The Cold War Desk, 1945–1949", path: "us-history/u3-d1-allies-enemies/", std: ["SS.9-12.US.37", "SS.9-12.US.39", "SS.9-12.US.40"] },
  "ush-u3-d3-korea": { course: "us-history", unit: 3, day: 3, title: "Day 3 · The War That Swung: Korea", path: "us-history/u3-d3-korea/", std: ["SS.9-12.US.35", "SS.9-12.US.37", "SS.9-12.US.40"] },
  "ush-u3-d5-nuclear-brink": { course: "us-history", unit: 3, day: 5, title: "Day 5 · Thirteen Days: Kennedy's Choices", path: "us-history/u3-d5-nuclear-brink/", std: ["SS.9-12.US.35", "SS.9-12.US.37", "SS.9-12.US.40"] },
  "ush-u3-d6-vietnam": { course: "us-history", unit: 3, day: 6, title: "Day 6 · Front Page: A Nation Divided", path: "us-history/u3-d6-vietnam/", std: ["SS.9-12.US.35", "SS.9-12.US.36", "SS.9-12.US.37", "SS.9-12.US.38", "SS.9-12.US.39", "SS.9-12.US.40", "SS.9-12.US.41"] },
  "ush-u4-d1-fight-segregation": { course: "us-history", unit: 4, day: 1, title: "Day 1 · The Case Against Segregation", path: "us-history/u4-d1-fight-segregation/", std: ["SS.9-12.US.42", "SS.9-12.US.43", "SS.9-12.US.44"] },
  "ush-u4-d2-nonviolence": { course: "us-history", unit: 4, day: 2, title: "Day 2 · The Nonviolence Strategy File", path: "us-history/u4-d2-nonviolence/", std: ["SS.9-12.US.42", "SS.9-12.US.43", "SS.9-12.US.44"] },
  "ush-u4-d3-who-else": { course: "us-history", unit: 4, day: 3, title: "Day 3 · Build the Exhibit: Who Else Fought?", path: "us-history/u4-d3-who-else/", std: ["SS.9-12.US.42", "SS.9-12.US.44"] },
  "ush-u5-d1-voters-change": { course: "us-history", unit: 5, day: 1, title: "Day 1 · Election Desk 1980", path: "us-history/u5-d1-voters-change/", std: ["SS.9-12.US.46", "SS.9-12.US.47", "SS.9-12.US.49"] },
  "ush-u5-d4-cold-war-ends": { course: "us-history", unit: 5, day: 4, title: "Day 4 · Who Ended the Cold War?", path: "us-history/u5-d4-cold-war-ends/", std: ["SS.9-12.US.48", "SS.9-12.US.49", "SS.9-12.US.50"] },
  "ush-u6-d1-superpower": { course: "us-history", unit: 6, day: 1, title: "Day 1 · Superpower Decision Desk", path: "us-history/u6-d1-superpower/", std: ["SS.9-12.US.52", "SS.9-12.US.53", "SS.9-12.US.55", "SS.9-12.US.56"] },
  "ush-u6-d2-crisis": { course: "us-history", unit: 6, day: 2, title: "Day 2 · Surviving 2008", path: "us-history/u6-d2-crisis/", std: ["SS.9-12.US.53", "SS.9-12.US.55"] },
  "ush-u6-d4-still-fighting": { course: "us-history", unit: 6, day: 4, title: "Day 4 · The Fight for Access", path: "us-history/u6-d4-still-fighting/", std: ["SS.9-12.US.51", "SS.9-12.US.55", "SS.9-12.US.56"] },
  "wh-p1u1-d4-conquistadors": { course: "world-history", unit: 1, day: 4, part: 1, title: "Day 4 · Council of Tlaxcala, 1519", path: "world-history/p1u1-d4-conquistadors/", std: ["SS.9-12.WH.3", "SS.9-12.WH.1"] },
  "wh-p1u1-d5-slave-trade": { course: "world-history", unit: 1, day: 5, part: 1, title: "Day 5 · Equiano's Words: An Exhibit", path: "world-history/p1u1-d5-slave-trade/", std: ["SS.9-12.WH.1", "SS.9-12.WH.3", "SS.9-12.WH.4"] },
  "wh-u2-d4-china": { course: "world-history", unit: 2, day: 4, title: "Day 4 · The Lin Family Under Mao", path: "world-history/u2-d4-china/", std: ["SS.9-12.WH.34", "SS.9-12.WH.35", "SS.9-12.WH.38"] },
  "wh-u2-d6-empires-end": { course: "world-history", unit: 2, day: 6, title: "Day 6 · India's Road to Freedom", path: "world-history/u2-d6-empires-end/", std: ["SS.9-12.WH.36", "SS.9-12.WH.34"] },
  "wh-u2-d7-africa": { course: "world-history", unit: 2, day: 7, title: "Day 7 · Freedom Day Advisers", path: "world-history/u2-d7-africa/", std: ["SS.9-12.WH.36", "SS.9-12.WH.34", "SS.9-12.WH.37"] },
  "wh-u2-d8-vietnam": { course: "world-history", unit: 2, day: 8, title: "Day 8 · Vietnam Turning Points", path: "world-history/u2-d8-vietnam/", std: ["SS.9-12.WH.36", "SS.9-12.WH.37", "SS.9-12.WH.34"] },
  "wh-u2-d11-1989": { course: "world-history", unit: 2, day: 11, title: "Day 11 · East Berlin, 1989", path: "world-history/u2-d11-1989/", std: ["SS.9-12.WH.34", "SS.9-12.WH.37", "SS.9-12.WH.35"] },
  "gov-u6-d1-checks-balances": { course: "government", unit: 6, day: 1, title: "Day 1 · Branch Wars", path: "civics/gov-u6-d1-checks-balances/", std: ["SS.9-12.Gov.4", "SS.9-12.Gov.9"] },
  "gov-u6-d2-iowa-government": { course: "government", unit: 6, day: 2, title: "Day 2 · Who Do I Call? Iowa Government", path: "civics/gov-u6-d2-iowa-government/", std: ["SS.9-12.Gov.18", "SS.9-12.Gov.19", "SS.9-12.Gov.20"] },
  "soc-u1-d5-prove-hot-take": { course: "sociology", unit: 1, day: 5, title: "Day 5 · Hot Take Lab", path: "sociology/u1-d5-prove-hot-take/", std: ["SS.9-12.Soc.1"] },
  "soc-u1-d6-study-people": { course: "sociology", unit: 1, day: 6, title: "Day 6 · Research Company", path: "sociology/u1-d6-study-people/", std: ["SS.9-12.Soc.1"] },
  "soc-u2-d4-team-up": { course: "sociology", unit: 2, day: 4, title: "Day 4 · Save Night Route 12", path: "sociology/u2-d4-team-up/", std: ["SS.9-12.Soc.7", "SS.9-12.Soc.8"] },
  "soc-u2-d5-everyday-life": { course: "sociology", unit: 2, day: 5, title: "Day 5 · Jaylen's Tuesday", path: "sociology/u2-d5-everyday-life/", std: ["SS.9-12.Soc.5", "SS.9-12.Soc.6", "SS.9-12.Soc.7", "SS.9-12.Soc.8"] },
  "soc-u3-d1-who-taught-you": { course: "sociology", unit: 3, day: 1, title: "Day 1 · Daniela's Scrapbook", path: "sociology/u3-d1-who-taught-you/", std: ["SS.9-12.Soc.9"] },
  "soc-u3-d5-groups-change-us": { course: "sociology", unit: 3, day: 5, title: "Day 5 · The Group Pressure Lab", path: "sociology/u3-d5-groups-change-us/", std: ["SS.9-12.Soc.11"] },
  "soc-u4-d2-bad-day": { course: "sociology", unit: 4, day: 2, title: "Day 2 · Same Bad Day, Three Wallets", path: "sociology/u4-d2-bad-day/", std: ["SS.9-12.Soc.12", "SS.9-12.Soc.13"] },
  "soc-u4-d6-fight-inequality": { course: "sociology", unit: 4, day: 6, title: "Day 6 · The Organizer's Toolkit", path: "sociology/u4-d6-fight-inequality/", std: ["SS.9-12.Soc.15"] }
};

// Iowa standard wording (Iowa Academic Standards for Social Studies) for every standard an in-use activity covers.
window.CLASS_STANDARDS = {
  "SS.9-12.WH.24": "Describe the economic, political and cultural factors that contributed to a new wave of European imperialism in the 19th century.",
  "SS.9-12.WH.25": "Compare and contrast the different imperialist systems created by European and other imperialist nations.",
  "SS.9-12.WH.27": "Compare the responses of resistance and adaptation to Western imperialism in the 19th century.",
  "SS.9-12.WH.29": "Analyze the causes that led to the outbreak of World War I and World War II.",
  "SS.9-12.WH.30": "Compare and contrast the rise of dictators including their methods of repression and persecution, specifically addressing the causes and impact of the Holocaust.",
  "SS.9-12.WH.31": "Assess the political and economic consequences and cultural developments after World War I and World War II.",
  "SS.9-12.WH.33": "Compare the experiences and perspectives of individuals affected by total war during World War I and World War II.",
  "SS.9-12.US.29": "Evaluate the multiple causes and effects of World War II.",
  "SS.9-12.US.30": "Evaluate the American response to the Holocaust.",
  "SS.9-12.US.31": "Analyze how labor and government actions during World War II influenced American economic systems, urbanization, and cultural development.",
  "SS.9-12.US.33": "Analyze diverse ideologies through primary and secondary sources, noting the impact on social, economic, and political institutions during World War II.",
  "SS.9-12.Soc.1": "Analyze the components of a sociological investigation.",
  "SS.9-12.Soc.2": "Compare and contrast the sociological perspective and how it differs from other social sciences.",
  "SS.9-12.Soc.4": "Explain the sociological theories that are the basis of sociology.",
  "SS.9-12.Soc.5": "Describe the components of culture.",
  "SS.9-12.Soc.6": "Analyze how culture influences individuals, including themselves.",
  "SS.9-12.Soc.7": "Evaluate important social institutions and how they respond to social needs.",
  "SS.9-12.Gov.1": "Analyze the origins of government with attention to the purpose(s) of government, and alternative models from other nations and groups.",
  "SS.9-12.Gov.3": "Analyze important founding and historical documents to the United States and the State of Iowa.",
  "SS.9-12.Gov.4": "Analyze the underlying principles established by the United States Constitution.",
  "SS.9-12.Gov.5": "Analyze the role of the government in maintaining order.",
  "SS.9-12.Gov.9": "Assess how the United States federal system divides powers between national and state governments.",
  "SS.9-12.Gov.12": "Critique the influence of intermediary institutions on government and policy.",
  "SS.9-12.Gov.6": "Analyze the function, duties, and authority of the legislative branch, including the process of lawmaking and the power of the purse.",
  "SS.9-12.Gov.7": "Analyze the function, duties, and authority of the executive branch, including the scope of presidential powers, executive orders, executive agreements, and the president's role in foreign and domestic policy.",
  "SS.9-12.Gov.8": "Analyze the function, duties, and authority of the judicial branch, including the power of judicial review and interpretation of laws.",
  "SS.9-12.Gov.11": "Analyze the historical, contemporary, and emerging patterns of political action and activism.",
  "SS.9-12.Gov.15": "Assess the contributions of exemplary Iowans and Americans who have played a role in promoting civic virtues and democratic principles.",
  "SS.9-12.Gov.16": "Analyze the concept of civic virtue and its importance to a well-functioning democracy.",
  "SS.9-12.Gov.17": "Analyze the rights, liberties, duties, and responsibilities of citizens of the United States and the state of Iowa.",
  "SS.9-12.Gov.13": "Analyze the electoral process and election systems in the United States, specifically Iowa election law including registration requirements, paper ballots, and absentee voting.",
  "SS.9-12.Gov.18": "Identify the function, duties, and authority of the government of the state of Iowa.",
  "SS.9-12.Gov.14": "Analyze the role of citizens in the U.S. political system, with attention to the definition of who is a citizen, the expansion of that definition over time.",
  "SS.9-12.Soc.11": "Explain the social construction of groups and their impact on the life chances of individuals.",
  "SS.9-12.Soc.12": "Explain the concept of social stratification and its influence on societal structures and individual opportunities.",
  "SS.9-12.Soc.13": "Analyze the effects of social inequality on groups and individuals.",
  "SS.9-12.Soc.15": "Evaluate how people and groups have responded to social inequality.",
  "SS.9-12.WH.34": "Map how communism and decolonization changed the global order from 1945 to 1991.",
  "SS.9-12.WH.35": "Compare and contrast the methods of control used by various forms of government during the Cold War.",
  "SS.9-12.WH.36": "Analyze the causes of decolonization within the context of the Cold War.",
  "SS.9-12.WH.37": "Explain how various groups promoted their interests and goals within the context of the Cold War.",
  "SS.9-12.Gov.19": "Identify the function, duties, and authority of the sovereign Meskwaki Nation tribal government.",
  "SS.9-12.Gov.20": "Identify the functions and organizational structures of Iowa's local governments."
};

// Works out the class for any id, even one not listed above.
window.classCourseFor = function (id) {
  id = String(id || "");
  const known = window.CLASS_ASSIGNMENTS[id];
  if (known) return known.course;
  if (id.startsWith("sociology-")) return "sociology";
  if (id.startsWith("civics-")) return "civics";
  if (id.startsWith("gov-")) return "government";
  if (id.startsWith("ush-") || id.startsWith("us-history-") || id.startsWith("wwii-graphic-reading")) return "us-history";
  return "world-history";
};
